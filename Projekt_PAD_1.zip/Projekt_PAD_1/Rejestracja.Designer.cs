﻿namespace Projekt_PAD_1
{
    partial class Rejestracja
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Rpowhaslo = new AltoControls.AltoTextBox();
            this.Remail = new AltoControls.AltoTextBox();
            this.Rnazwisko = new AltoControls.AltoTextBox();
            this.Rimie = new AltoControls.AltoTextBox();
            this.RbtnZarejestruj = new AltoControls.AltoButton();
            this.Rpowrot = new AltoControls.AltoButton();
            this.Rimie1 = new System.Windows.Forms.TextBox();
            this.Rlogin = new System.Windows.Forms.TextBox();
            this.Rhaslo = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Rpowhaslo
            // 
            this.Rpowhaslo.BackColor = System.Drawing.Color.Transparent;
            this.Rpowhaslo.Br = System.Drawing.Color.White;
            this.Rpowhaslo.Font = new System.Drawing.Font("Bell MT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Rpowhaslo.ForeColor = System.Drawing.Color.DimGray;
            this.Rpowhaslo.Location = new System.Drawing.Point(44, 387);
            this.Rpowhaslo.Name = "Rpowhaslo";
            this.Rpowhaslo.Size = new System.Drawing.Size(225, 42);
            this.Rpowhaslo.TabIndex = 3;
            this.Rpowhaslo.Text = "Powtórz swoje hasło:";
            this.Rpowhaslo.Click += new System.EventHandler(this.Rpowhaslo_Click);
            // 
            // Remail
            // 
            this.Remail.BackColor = System.Drawing.Color.Transparent;
            this.Remail.Br = System.Drawing.Color.White;
            this.Remail.Font = new System.Drawing.Font("Bell MT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Remail.ForeColor = System.Drawing.Color.DimGray;
            this.Remail.Location = new System.Drawing.Point(44, 203);
            this.Remail.Name = "Remail";
            this.Remail.Size = new System.Drawing.Size(225, 42);
            this.Remail.TabIndex = 4;
            this.Remail.Text = "Podaj swój E-mail";
            this.Remail.Click += new System.EventHandler(this.Remail_Click);
            // 
            // Rnazwisko
            // 
            this.Rnazwisko.BackColor = System.Drawing.Color.Transparent;
            this.Rnazwisko.Br = System.Drawing.Color.White;
            this.Rnazwisko.Font = new System.Drawing.Font("Bell MT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Rnazwisko.ForeColor = System.Drawing.Color.DimGray;
            this.Rnazwisko.Location = new System.Drawing.Point(44, 155);
            this.Rnazwisko.Name = "Rnazwisko";
            this.Rnazwisko.Size = new System.Drawing.Size(225, 42);
            this.Rnazwisko.TabIndex = 5;
            this.Rnazwisko.Text = "Wprowadź swoje nazwisko:";
            this.Rnazwisko.Click += new System.EventHandler(this.Rnazwisko_Click);
            // 
            // Rimie
            // 
            this.Rimie.BackColor = System.Drawing.Color.Transparent;
            this.Rimie.Br = System.Drawing.Color.White;
            this.Rimie.Font = new System.Drawing.Font("Bell MT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Rimie.ForeColor = System.Drawing.Color.DimGray;
            this.Rimie.Location = new System.Drawing.Point(44, 93);
            this.Rimie.Name = "Rimie";
            this.Rimie.Size = new System.Drawing.Size(225, 42);
            this.Rimie.TabIndex = 6;
            this.Rimie.Text = "Wprowadź swoje imię:";
            this.Rimie.Click += new System.EventHandler(this.Rimie_Click);
            // 
            // RbtnZarejestruj
            // 
            this.RbtnZarejestruj.Active1 = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(168)))), ((int)(((byte)(183)))));
            this.RbtnZarejestruj.Active2 = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(164)))), ((int)(((byte)(183)))));
            this.RbtnZarejestruj.BackColor = System.Drawing.Color.Transparent;
            this.RbtnZarejestruj.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.RbtnZarejestruj.Font = new System.Drawing.Font("Comic Sans MS", 10F, System.Drawing.FontStyle.Bold);
            this.RbtnZarejestruj.ForeColor = System.Drawing.Color.Black;
            this.RbtnZarejestruj.Inactive1 = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(188)))), ((int)(((byte)(210)))));
            this.RbtnZarejestruj.Inactive2 = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(167)))), ((int)(((byte)(188)))));
            this.RbtnZarejestruj.Location = new System.Drawing.Point(224, 456);
            this.RbtnZarejestruj.Name = "RbtnZarejestruj";
            this.RbtnZarejestruj.Radius = 10;
            this.RbtnZarejestruj.Size = new System.Drawing.Size(198, 43);
            this.RbtnZarejestruj.Stroke = false;
            this.RbtnZarejestruj.StrokeColor = System.Drawing.Color.Gray;
            this.RbtnZarejestruj.TabIndex = 7;
            this.RbtnZarejestruj.Text = "Zarejestruj";
            this.RbtnZarejestruj.Transparency = false;
            this.RbtnZarejestruj.Click += new System.EventHandler(this.RbtnZarejestruj_Click);
            // 
            // Rpowrot
            // 
            this.Rpowrot.Active1 = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(168)))), ((int)(((byte)(183)))));
            this.Rpowrot.Active2 = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(164)))), ((int)(((byte)(183)))));
            this.Rpowrot.BackColor = System.Drawing.Color.Transparent;
            this.Rpowrot.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.Rpowrot.Font = new System.Drawing.Font("Comic Sans MS", 10F, System.Drawing.FontStyle.Bold);
            this.Rpowrot.ForeColor = System.Drawing.Color.Black;
            this.Rpowrot.Inactive1 = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(188)))), ((int)(((byte)(210)))));
            this.Rpowrot.Inactive2 = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(167)))), ((int)(((byte)(188)))));
            this.Rpowrot.Location = new System.Drawing.Point(12, 456);
            this.Rpowrot.Name = "Rpowrot";
            this.Rpowrot.Radius = 10;
            this.Rpowrot.Size = new System.Drawing.Size(198, 43);
            this.Rpowrot.Stroke = false;
            this.Rpowrot.StrokeColor = System.Drawing.Color.Gray;
            this.Rpowrot.TabIndex = 8;
            this.Rpowrot.Text = "Powrót";
            this.Rpowrot.Transparency = false;
            this.Rpowrot.Click += new System.EventHandler(this.Rpowrot_Click);
            // 
            // Rimie1
            // 
            this.Rimie1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Rimie1.Location = new System.Drawing.Point(61, 32);
            this.Rimie1.Name = "Rimie1";
            this.Rimie1.Size = new System.Drawing.Size(188, 20);
            this.Rimie1.TabIndex = 9;
            this.Rimie1.TextChanged += new System.EventHandler(this.Rimie1_TextChanged);
            // 
            // Rlogin
            // 
            this.Rlogin.Location = new System.Drawing.Point(44, 271);
            this.Rlogin.Name = "Rlogin";
            this.Rlogin.Size = new System.Drawing.Size(100, 20);
            this.Rlogin.TabIndex = 10;
            this.Rlogin.TextChanged += new System.EventHandler(this.Rlogin_TextChanged);
            // 
            // Rhaslo
            // 
            this.Rhaslo.Location = new System.Drawing.Point(44, 324);
            this.Rhaslo.Name = "Rhaslo";
            this.Rhaslo.Size = new System.Drawing.Size(100, 20);
            this.Rhaslo.TabIndex = 11;
            this.Rhaslo.TextChanged += new System.EventHandler(this.Rhaslo_TextChanged);
            // 
            // Rejestracja
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(434, 511);
            this.Controls.Add(this.Rhaslo);
            this.Controls.Add(this.Rlogin);
            this.Controls.Add(this.Rimie1);
            this.Controls.Add(this.Rpowrot);
            this.Controls.Add(this.RbtnZarejestruj);
            this.Controls.Add(this.Rimie);
            this.Controls.Add(this.Rnazwisko);
            this.Controls.Add(this.Remail);
            this.Controls.Add(this.Rpowhaslo);
            this.Name = "Rejestracja";
            this.Text = "Rejestracja";
            this.Load += new System.EventHandler(this.Rejestracja_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private AltoControls.AltoTextBox Rpowhaslo;
        private AltoControls.AltoTextBox Remail;
        private AltoControls.AltoTextBox Rnazwisko;
        private AltoControls.AltoTextBox Rimie;
        private AltoControls.AltoButton RbtnZarejestruj;
        private AltoControls.AltoButton Rpowrot;
        private System.Windows.Forms.TextBox Rimie1;
        private System.Windows.Forms.TextBox Rlogin;
        private System.Windows.Forms.TextBox Rhaslo;
    }
}